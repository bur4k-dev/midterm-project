using UnityEngine;

public class Bounce : MonoBehaviour
{
    public float jumpForce = 10f;  // Z�plama g�c�
    public float randomForceRange = 5f;  // Savrulma kuvvetinin rastgele aral���
    private int objectsInTrigger = 0;  // Kutuya giren objelerin say�s�n� tutacak
    private Rigidbody secondObjectRb = null;  // �kinci giren objenin Rigidbody'si

    void OnTriggerEnter(Collider other)
    {
        // Yaln�zca "Player" etiketi olan objelere tepki verir
        if (other.CompareTag("Player"))
        {
            objectsInTrigger++;

            // �kinci obje girerse
            if (objectsInTrigger == 2)
            {
                // �kinci objeye Rigidbody al
                secondObjectRb = other.GetComponent<Rigidbody>();

                // E�er Rigidbody varsa rastgele kuvvet uygula
                if (secondObjectRb != null)
                {
                    ApplyRandomForce(secondObjectRb);
                }
            }
        }
    }

    // Kutuya objeler ��karsa obje say�s�n� azalt
    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            objectsInTrigger--;

            // E�er ��kan obje ikinci obje ise Rigidbody'yi s�f�rla
            if (secondObjectRb != null && other.GetComponent<Rigidbody>() == secondObjectRb)
            {
                secondObjectRb = null;
            }
        }
    }

    // Objeye rastgele kuvvet ekleme fonksiyonu
    void ApplyRandomForce(Rigidbody rb)
    {
        if (rb != null)
        {
            // X, Y, Z eksenlerinde rastgele kuvvet
            Vector3 randomForce = new Vector3(
                Random.Range(3, randomForceRange), // X ekseninde savrulma
                Random.Range(0, jumpForce), // Y ekseninde z�plama
                Random.Range(3, randomForceRange)  // Z ekseninde savrulma
            );

            rb.AddForce(randomForce, ForceMode.Impulse);
        }
    }
}
